
## TRIM's internals

# dat: a data.frame
# cmd: a TRIMcommand object
#
do_trim <- function(dat,cmd){
  if(trim_weighting(cmd)){
    print("weighted trim :-)")
  } else {
    # do that
  }
  
  # some more calculations
  # return the result.
  
}



